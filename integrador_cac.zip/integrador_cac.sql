-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 19-12-2023 a las 23:52:24
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `integrador_cac`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `oradores`
--

CREATE TABLE `oradores` (
  `id_orador` int(11) NOT NULL,
  `nombre` varchar(40) NOT NULL,
  `apellido` varchar(40) NOT NULL,
  `mail` varchar(50) NOT NULL,
  `tema` varchar(60) NOT NULL,
  `Fecha_Alta` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Volcado de datos para la tabla `oradores`
--

INSERT INTO `oradores` (`id_orador`, `nombre`, `apellido`, `mail`, `tema`, `Fecha_Alta`) VALUES
(1, 'Pepe', 'Juancho', 'pepejuancho@hotmail.com', 'orador', '2023-12-19 22:35:13'),
(2, 'Manuel', 'Pancho', 'manuelpancho@hotmail.com', 'ser orador', '2023-12-19 22:36:17'),
(3, 'Lisa', 'Pipier', 'lisapupier@hotmail.com', 'ser orador', '2023-12-19 22:39:02'),
(4, 'Aurora', 'Estrella', 'auroraestrella@hotmail.com', 'ser orador', '2023-12-19 22:40:47'),
(5, 'Esteban', 'Quitto', 'estebanquitto@hotmail.com', 'orador', '2023-12-19 22:41:49'),
(6, 'Ana', 'Banko', 'anablanko@hotmail.com', 'orador', '2023-12-19 22:42:22'),
(7, 'Matias', 'Gatto', 'matiasgatto@hotmail.com', 'ser orador', '2023-12-19 22:42:56'),
(8, 'Ivan', 'Gatto', 'ivangatto@hotmail.com', 'ser orador', '2023-12-19 22:43:21'),
(9, 'Lucas', 'Bekam', 'lucasbekam@hotmail.com', 'orador', '2023-12-19 22:44:01'),
(10, 'Lila', 'Blanco', 'lilablanco@hotmail.com', 'orador', '2023-12-19 22:45:29');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `oradores`
--
ALTER TABLE `oradores`
  ADD PRIMARY KEY (`id_orador`),
  ADD UNIQUE KEY `mail` (`mail`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `oradores`
--
ALTER TABLE `oradores`
  MODIFY `id_orador` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
